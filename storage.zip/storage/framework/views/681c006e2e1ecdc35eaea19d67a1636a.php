<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Dosen</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 600px;
            margin: 30px auto;
            padding: 0 20px;
        }

        label {
            display: inline-block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input {
            width: 100%;
            box-sizing: border-box;
            padding: 9px;
        }

        button {
            padding: 9px 14px;
            cursor: pointer;
        }

        .errors {
            padding: 10px 10px 10px 30px;
            background-color: #ffecec;
            color: #a40000;
        }
    </style>
</head>
<body>
    <h1>Tambah Dosen</h1>

    <?php if($errors->any()): ?>
        <ul class="errors">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>

    <form action="<?php echo e(route('dosen.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <p>
            <label for="nidn">NIDN</label><br>
            <input type="text" id="nidn" name="nidn" value="<?php echo e(old('nidn')); ?>" maxlength="20" required>
        </p>

        <p>
            <label for="nama">Nama</label><br>
            <input type="text" id="nama" name="nama" value="<?php echo e(old('nama')); ?>" maxlength="100" required>
        </p>

        <p>
            <label for="bidang_keahlian">Bidang Keahlian</label><br>
            <input type="text" id="bidang_keahlian" name="bidang_keahlian" value="<?php echo e(old('bidang_keahlian')); ?>" maxlength="100" required>
        </p>

        <p>
            <label for="email">Email</label><br>
            <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" maxlength="100">
        </p>

        <p>
            <label for="no_telepon">No. Telepon</label><br>
            <input type="text" id="no_telepon" name="no_telepon" value="<?php echo e(old('no_telepon')); ?>" maxlength="20">
        </p>

        <button type="submit">Simpan</button>
        <a href="<?php echo e(route('dosen.index')); ?>">Batal</a>
    </form>
</body>
</html><?php /**PATH F:\ase11\belajar-laravel\resources\views/dosen/create.blade.php ENDPATH**/ ?>