<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ubah Data Mahasiswa</title>
</head>
<body>
    <h1>Ubah Data Mahasiswa</h1>

    <?php if($errors->any()): ?>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>

    <form action="<?php echo e(route('mahasiswa.update', $mahasiswa->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <p>
            <label for="nim">NIM</label><br>
            <input
                type="text"
                id="nim"
                name="nim"
                value="<?php echo e(old('nim', $mahasiswa->nim)); ?>"
                maxlength="20"
                required
            >
        </p>

        <p>
            <label for="nama">Nama</label><br>
            <input
                type="text"
                id="nama"
                name="nama"
                value="<?php echo e(old('nama', $mahasiswa->nama)); ?>"
                maxlength="100"
                required
            >
        </p>

        <p>
            <label for="jurusan">Jurusan</label><br>
            <input
                type="text"
                id="jurusan"
                name="jurusan"
                value="<?php echo e(old('jurusan', $mahasiswa->jurusan)); ?>"
                maxlength="100"
                required
            >
        </p>

        <p>
            <label for="angkatan">Angkatan</label><br>
            <input
                type="number"
                id="angkatan"
                name="angkatan"
                value="<?php echo e(old('angkatan', $mahasiswa->angkatan)); ?>"
                min="1900"
                max="2200"
                required
            >
        </p>

        <p>
            <label for="email">Email</label><br>
            <input
                type="email"
                id="email"
                name="email"
                value="<?php echo e(old('email', $mahasiswa->email)); ?>"
                maxlength="100"
            >
        </p>

        <button type="submit">Simpan Perubahan</button>
        <a href="<?php echo e(route('mahasiswa.index')); ?>">Batal</a>
    </form>
</body>
</html><?php /**PATH F:\ase11\belajar-laravel\resources\views/mahasiswa/edit.blade.php ENDPATH**/ ?>