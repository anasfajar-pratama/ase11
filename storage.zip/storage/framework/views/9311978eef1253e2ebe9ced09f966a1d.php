<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Data Mahasiswa'); ?> · <?php echo e(config('app.name', 'Laravel')); ?></title>
    <style>
        :root {
            --ink:#172235; --muted:#66758a; --line:#dce5ef; --paper:#f5f8fc;
            --card:#fff; --blue:#2563eb; --blue-dark:#1648a4; --blue-soft:#eaf2ff;
            --teal:#087f8c; --green:#187845; --red:#b42318; --shadow:0 12px 30px rgba(21,51,88,.08);
        }
        * { box-sizing:border-box; }
        body { margin:0; color:var(--ink); background:var(--paper); font:15px/1.55 Inter,ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif; }
        a { color:var(--blue-dark); }
        button,input { font:inherit; }
        button { cursor:pointer; }
        code { padding:2px 5px; border-radius:5px; background:#eef3f8; font-family:ui-monospace,SFMono-Regular,Consolas,monospace; font-size:.9em; }
        .topbar { background:#102a56; color:#dbeafe; }
        .topbar-inner,.container { width:min(1120px,calc(100% - 36px)); margin:auto; }
        .topbar-inner { display:flex; justify-content:space-between; gap:12px; padding:9px 0; font-size:.82rem; }
        .navbar { background:#fff; border-bottom:1px solid var(--line); }
        .nav-inner { display:flex; align-items:center; justify-content:space-between; gap:20px; min-height:70px; }
        .brand { display:flex; align-items:center; gap:10px; color:var(--ink); text-decoration:none; font-weight:850; }
        .brand-mark { display:grid; place-items:center; width:38px; height:38px; border-radius:12px; color:#fff; background:linear-gradient(135deg,#f5753a,#e52e64); font-weight:900; }
        .nav-links { display:flex; align-items:center; gap:16px; }
        .nav-links a { color:var(--muted); text-decoration:none; font-weight:650; }
        .nav-links a:hover { color:var(--blue-dark); }
        .main { padding:38px 0 70px; }
        .page-heading { display:flex; justify-content:space-between; align-items:flex-end; gap:20px; margin-bottom:23px; }
        .eyebrow { margin:0 0 4px; color:var(--blue); font-size:.74rem; font-weight:850; letter-spacing:.1em; text-transform:uppercase; }
        h1,h2,h3 { margin:0; line-height:1.2; letter-spacing:-.025em; }
        h1 { font-size:clamp(1.8rem,4vw,2.65rem); }
        h2 { font-size:1.35rem; }
        h3 { font-size:1.05rem; }
        .muted { color:var(--muted); }
        .small { font-size:.84rem; }
        .grid { display:grid; gap:16px; }
        .stats { grid-template-columns:repeat(3,1fr); margin-bottom:20px; }
        .card { padding:20px; border:1px solid var(--line); border-radius:16px; background:var(--card); box-shadow:var(--shadow); }
        .stat { display:flex; justify-content:space-between; align-items:flex-start; gap:10px; }
        .stat strong { display:block; margin-top:3px; font-size:1.75rem; }
        .stat-icon { display:grid; place-items:center; width:38px; height:38px; border-radius:11px; color:var(--blue-dark); background:var(--blue-soft); }
        .toolbar { display:flex; justify-content:space-between; align-items:center; gap:14px; margin-bottom:16px; }
        .search { display:flex; flex:1; gap:8px; }
        .input,.select { width:100%; padding:10px 12px; border:1px solid #cbd8e6; border-radius:9px; color:var(--ink); background:#fff; outline:0; }
        .input:focus,.select:focus { border-color:#73a0e2; box-shadow:0 0 0 3px #e4eeff; }
        .btn { display:inline-flex; align-items:center; justify-content:center; gap:7px; min-height:41px; padding:9px 14px; border:1px solid #cbd8e6; border-radius:9px; color:var(--ink); background:#fff; text-decoration:none; font-weight:750; white-space:nowrap; }
        .btn:hover { background:#f6faff; border-color:#9fb9d8; }
        .btn-primary { color:#fff; border-color:var(--blue); background:var(--blue); }
        .btn-primary:hover { color:#fff; background:var(--blue-dark); }
        .btn-danger { color:var(--red); border-color:#f1bdb7; background:#fffafa; }
        .btn-sm { min-height:34px; padding:6px 10px; font-size:.86rem; }
        .table-wrap { overflow:auto; }
        table { width:100%; border-collapse:collapse; }
        th,td { padding:13px 12px; border-bottom:1px solid var(--line); text-align:left; vertical-align:middle; }
        th { color:var(--muted); background:#f7faff; font-size:.77rem; letter-spacing:.05em; text-transform:uppercase; }
        tr:last-child td { border-bottom:0; }
        .student-name { font-weight:800; }
        .student-name small { display:block; margin-top:2px; color:var(--muted); font-weight:400; }
        .actions { display:flex; flex-wrap:wrap; gap:6px; }
        .alert { display:flex; justify-content:space-between; gap:12px; margin-bottom:18px; padding:12px 14px; border-radius:10px; }
        .alert-success { color:#155b36; border:1px solid #bde4ca; background:#ecfbf0; }
        .alert-error { color:#8d2018; border:1px solid #f0c2bc; background:#fff3f2; }
        .alert button { border:0; color:inherit; background:transparent; font-size:1.1rem; }
        .empty { padding:40px 20px; text-align:center; }
        .empty-icon { margin:0 auto 10px; font-size:2rem; }
        .pagination { display:flex; justify-content:space-between; align-items:center; gap:12px; margin-top:18px; }
        .pagination-links { display:flex; gap:7px; }
        .page-link { padding:7px 10px; border:1px solid var(--line); border-radius:8px; text-decoration:none; background:#fff; }
        .page-link.disabled { color:#a7b2c0; pointer-events:none; background:#f7f9fb; }
        .form-layout { max-width:770px; margin:auto; }
        .form-grid { display:grid; grid-template-columns:repeat(2,1fr); gap:16px; }
        .field { display:block; }
        .field.full { grid-column:1/-1; }
        .field label { display:block; margin-bottom:6px; font-weight:750; }
        .required { color:var(--red); }
        .error { margin:5px 0 0; color:var(--red); font-size:.84rem; }
        .form-actions { display:flex; justify-content:space-between; align-items:center; gap:12px; margin-top:22px; padding-top:18px; border-top:1px solid var(--line); }
        .detail-grid { display:grid; grid-template-columns:1.2fr .8fr; gap:18px; }
        .profile { display:flex; align-items:center; gap:14px; padding-bottom:20px; border-bottom:1px solid var(--line); }
        .avatar { display:grid; place-items:center; flex:none; width:62px; height:62px; border-radius:18px; color:#fff; background:linear-gradient(135deg,#2563eb,#087f8c); font-size:1.35rem; font-weight:850; }
        .info-list { margin:0; }
        .info-row { display:grid; grid-template-columns:150px 1fr; gap:12px; padding:12px 0; border-bottom:1px solid var(--line); }
        .info-row:last-child { border-bottom:0; }
        .info-row dt { color:var(--muted); }
        .info-row dd { margin:0; font-weight:650; }
        .tip { color:#245173; border:1px solid #c6ddf5; background:#eff7ff; }
        footer { padding:22px 0; border-top:1px solid var(--line); color:var(--muted); font-size:.85rem; }
        @media(max-width:740px) {
            .topbar-inner,.nav-inner { width:min(100% - 26px,1120px); }
            .nav-inner { min-height:60px; }
            .nav-links { gap:9px; font-size:.88rem; }
            .container { width:calc(100% - 26px); }
            .main { padding-top:25px; }
            .page-heading,.toolbar { display:block; }
            .page-heading .btn,.toolbar .btn { margin-top:12px; }
            .stats { grid-template-columns:1fr; }
            .search { margin-top:12px; }
            .form-grid,.detail-grid { grid-template-columns:1fr; }
            .field.full { grid-column:auto; }
        }
        @media print {
            .topbar,.navbar,.btn,.actions,.search,footer { display:none!important; }
            body { background:#fff; font-size:11pt; }
            .container { width:100%; }
            .main { padding:0; }
            .card { box-shadow:none; }
        }
    </style>
</head>
<body>
    <div class="topbar">
        <div class="topbar-inner">
            <span>Praktikum Laravel · Project Akhir</span>
            <span>Data Mahasiswa</span>
        </div>
    </div>
    <nav class="navbar">
        <div class="container nav-inner">
            <a class="brand" href="<?php echo e(route('mahasiswa.index')); ?>">
                <span class="brand-mark">L</span>
                <span>Data Mahasiswa</span>
            </a>
            <div class="nav-links">
                <a href="<?php echo e(route('mahasiswa.index')); ?>">Daftar</a>
                <a href="<?php echo e(route('mahasiswa.create')); ?>">Tambah data</a>
            </div>
        </div>
    </nav>
    <main class="main">
        <div class="container">
            <?php if(session('success')): ?>
                <div class="alert alert-success" role="alert">
                    <span>✓ <?php echo e(session('success')); ?></span>
                    <button type="button" onclick="this.parentElement.remove()" aria-label="Tutup">×</button>
                </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-error" role="alert">
                    <span><?php echo e(session('error')); ?></span>
                    <button type="button" onclick="this.parentElement.remove()" aria-label="Tutup">×</button>
                </div>
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>
    <footer>
        <div class="container">
            <strong>Data Mahasiswa</strong> · Contoh aplikasi CRUD Laravel untuk pembelajaran.
        </div>
    </footer>
</body>
</html><?php /**PATH F:\ase11\belajar-laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>