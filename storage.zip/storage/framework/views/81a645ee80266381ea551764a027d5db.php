<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Dosen</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 1100px;
            margin: 30px auto;
            padding: 0 20px;
        }

        h1 {
            margin-bottom: 10px;
        }

        a {
            color: #155eef;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #999;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .success {
            padding: 10px;
            background-color: #e8f7e8;
            color: #176b17;
        }

        form {
            display: inline;
        }

        button {
            cursor: pointer;
        }
    </style>
</head>
<body>
    <h1>Data Dosen</h1>

    <?php if(session('success')): ?>
        <p class="success"><?php echo e(session('success')); ?></p>
    <?php endif; ?>

    <p>
        <a href="<?php echo e(route('dosen.create')); ?>">Tambah Dosen</a>
        |
        <a href="<?php echo e(route('mahasiswa.index')); ?>">Data Mahasiswa</a>
    </p>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>NIDN</th>
                <th>Nama</th>
                <th>Bidang Keahlian</th>
                <th>Email</th>
                <th>No. Telepon</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dsn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($dsn->nidn); ?></td>
                    <td><?php echo e($dsn->nama); ?></td>
                    <td><?php echo e($dsn->bidang_keahlian); ?></td>
                    <td><?php echo e($dsn->email); ?></td>
                    <td><?php echo e($dsn->no_telepon); ?></td>
                    <td>
                        <a href="<?php echo e(route('dosen.edit', $dsn->id)); ?>">Ubah</a>

                        <form
                            action="<?php echo e(route('dosen.destroy', $dsn->id)); ?>"
                            method="POST"
                            style="display: inline"
                            onsubmit="return confirm('Yakin ingin menghapus data dosen ini?')"
                        >
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7">Belum ada data dosen.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html><?php /**PATH F:\ase11\belajar-laravel\resources\views/dosen/index.blade.php ENDPATH**/ ?>